const express = require('express');
const fs = require('fs');
const path = require('path');
const session = require('express-session');

const app = express();

const PORT = 3000;

// ======================================
// MIDDLEWARES
// ======================================

app.use(express.json());

app.use(session({

  secret: 'autoelite_secret',

  resave: false,

  saveUninitialized: false,

  cookie: {
    secure: false
  }

}));

app.use(express.static(
  path.join(__dirname, 'public')
));

// ======================================
// ARCHIVOS
// ======================================

const USERS_FILE = path.join(
  __dirname,
  'data',
  'users.json'
);

// ======================================
// CREAR JSON SI NO EXISTE
// ======================================

if (!fs.existsSync(USERS_FILE)) {

  fs.mkdirSync(
    path.join(__dirname, 'data'),
    { recursive: true }
  );

  fs.writeFileSync(
    USERS_FILE,
    '[]'
  );

}

// ======================================
// HOME
// ======================================

app.get('/', (req, res) => {

  res.sendFile(
    path.join(__dirname, 'public', 'index.html')
  );

});

// ======================================
// REGISTRO
// ======================================

app.post('/api/auth/register', (req, res) => {

  const {
    name,
    email,
    password
  } = req.body;

  if (!name || !email || !password) {

    return res.json({

      ok: false,

      error: 'Completa todos los campos'

    });

  }

  const users = JSON.parse(
    fs.readFileSync(USERS_FILE)
  );

  const exists = users.find(
    u => u.email === email
  );

  if (exists) {

    return res.json({

      ok: false,

      error: 'Ese correo ya existe'

    });

  }

  const newUser = {

    id: Date.now(),

    name,

    email,

    password

  };

  users.push(newUser);

  fs.writeFileSync(

    USERS_FILE,

    JSON.stringify(users, null, 2)

  );

  // CREAR SESIÓN
  req.session.user = {

    id: newUser.id,

    name: newUser.name,

    email: newUser.email

  };

  res.json({

    ok: true,

    message: 'Cuenta creada'

  });

});

// ======================================
// LOGIN
// ======================================

app.post('/api/auth/login', (req, res) => {

  const {
    email,
    password
  } = req.body;

  const users = JSON.parse(
    fs.readFileSync(USERS_FILE)
  );

  const user = users.find(u =>

    u.email === email &&
    u.password === password

  );

  if (!user) {

    return res.json({

      ok: false,

      error: 'Correo o contraseña incorrectos'

    });

  }

  // GUARDAR SESIÓN
  req.session.user = {

    id: user.id,

    name: user.name,

    email: user.email

  };

  res.json({

    ok: true,

    message: 'Inicio exitoso'

  });

});

// ======================================
// OBTENER SESIÓN
// ======================================

app.get('/api/auth/me', (req, res) => {

  res.json({

    user: req.session.user || null

  });

});

// ======================================
// CERRAR SESIÓN
// ======================================

app.post('/api/auth/logout', (req, res) => {

  req.session.destroy(() => {

    res.json({

      ok: true

    });

  });

});

// ======================================
// SERVIDOR
// ======================================

app.listen(PORT, () => {

  console.log(
    `Servidor funcionando en http://localhost:${PORT}`
  );

});